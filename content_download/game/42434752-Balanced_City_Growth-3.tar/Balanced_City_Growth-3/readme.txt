Balanced City Growth
A gamescript for OpenTTD

Balanced city growth is a game script which changes how cities grow in several ways outlined below.

1. Cities now require cargo to be delivered each month.  Which cargos are demanded depends heavily on if you're using the base industries, or if you're using an industry set such as ECS or FIRS.  This script will work with any of those three, however you must set which one you're using in the settings first.

2. In addition to requiring cargo, cities can also stockpile cargo over an above the goal amount.  The maximum amount is capped at ten times the required amount for that particular cargo.  If nothing is supplied, the required amount will be deducted from the stockpile each month until the stockpile reaches zero.

3. The first required cargo will always be passengers.  Each month, the script will check to see if any passengers have been transported from a town, and will only procede with the rest of the calculations if this is true.  This is intended to reduce the strain for larger maps where there would otherwise be lots of towns to calculate.

4. Maps now have a target number of cities which fluctuates by map size.  The formula for goal cities = sqrt(# of tiles in the map) / 128.  Cities are grouped together into tiers according to population.  For each city, the script will compare the number of cities in the same or higher tier and adjust the goal requirements up or down depending if there are less or more cities than the target amount.  The intent of this feature is to encourage players to expand their networks to grow many different cities, rather than focus on one megapolis.  Players who can successfully supply many more cities than the target amount will be rewarded with vastly reduced goal amounts, however passengers and mail will not be affected positively or negatively by this.

4. As a measure to improve performance on larger maps, the script will pause the game while processing the monthly calculations. The time this takes depends heavily on the number of towns with an active passenger network.  Usually it will only be a fraction of a second, but on a 2048x2048 map with lots of towns and every single on of them connected to the network it could take several minutes.  I recommend playing the game with build while paused allowed for all maps, as well as less towns if you're going to play on a large map.

5. The normal town GUI will not function anymore.  Instead, a town's text box will be updated with the stockpile amount, the supplied amount(previous month), and the required amount for the next month.  Below each town's name, you'll also see a sign indicating the number of days in between growths.

PERFORMANCE TIPS
* Enable build while paused at all times.
* On larger maps, select a lower setting for the number of towns.
* Balanced City Growth's main calculations take place on the first of each month, so it works well with the daylength patch.