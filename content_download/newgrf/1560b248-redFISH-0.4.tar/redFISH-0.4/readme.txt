

Sunk Rock [Ferry]             Introduced: 1870; Speed: 18.0mph
Barletta [Paddle Steamer]     Introduced: 1870; Speed: 23.0mph
Harbour Point [Utility Vessel]  Introduced: 1870; Speed: 19.0mph
Harbour Point [Trawler]       Introduced: 1870; Speed: 19.0mph
Meteor [Freighter]            Introduced: 1870; Speed: 18.0mph
Little Cumbrae [Freighter]    Introduced: 1870; Speed: 18.0mph
Whitgift [Freight Barge]      Introduced: 1870; Speed: 16.0mph
Saint Marie [Barge Tug]       Introduced: 1870; Speed: 16.0mph
Fish Island [Trawler]         Introduced: 1880; Speed: 17.0mph
Castle Point [Steamer]        Introduced: 1900; Speed: 25.0mph
Altamira [Freighter]          Introduced: 1900; Speed: 18.0mph
Pine Island [Log Tug]         Introduced: 1900; Speed: 13.0mph
Grizenesse [Freighter]        Introduced: 1905; Speed: 20.0mph
Frisco Bay [Freighter]        Introduced: 1915; Speed: 18.0mph
Fastnet [Paddle Steamer]      Introduced: 1918; Speed: 23.0mph
Eddystone [Tanker]            Introduced: 1920; Speed: 20.0mph
Geneva [Freight Barge]        Introduced: 1920; Speed: 16.0mph
Hopetown [Tanker]             Introduced: 1926; Speed: 20.0mph
Cape Spear [Trawler]          Introduced: 1948; Speed: 20.0mph
Grindavik [Reefer]            Introduced: 1950; Speed: 23.0mph
Patos Island [Ferry]          Introduced: 1953; Speed: 22.0mph
Santorini [Freighter]         Introduced: 1953; Speed: 20.0mph
Marstein [Freighter]          Introduced: 1954; Speed: 21.0mph
Capo Sandalo [Ferry]          Introduced: 1959; Speed: 23.0mph
Shark Island [Livestock Ship]  Introduced: 1960; Speed: 26.0mph
Constance [Freight Barge]     Introduced: 1961; Speed: 18.0mph
Feodosiya [Hydrofoil]         Introduced: 1967; Speed: 40.0mph
Cadiz [Freighter]             Introduced: 1970; Speed: 20.0mph
Thunder Bay [Hovercraft]      Introduced: 1972; Speed: 46.0mph
Yokohama [Tanker]             Introduced: 1973; Speed: 22.0mph
Finisterre [Freighter]        Introduced: 1974; Speed: 22.0mph
Matsushima [Hydrofoil]        Introduced: 1978; Speed: 56.0mph
Nieuwpoort [Container Feeder]  Introduced: 1979; Speed: 30.0mph
Maspalomas [Freighter]        Introduced: 1985; Speed: 20.0mph
Dieze [Container Barge]       Introduced: 1990; Speed: 25.0mph
Enoshima [Fast Ferry]         Introduced: 1997; Speed: 50.0mph
Endeavour [Rig Supply Fast Catamaran]  Introduced: 1998; Speed: 45.0mph
Mount Blaze [Fast Ferry]      Introduced: 2008; Speed: 60.0mph

redFISH readme

-----------------------------------

Contents:

1 About
2 Usage and Parameters
3 Building from source
3.1 Speed issues
3.2 Obtaining the source
4 Credits
5 License


-------
1 About
-------

This is a fork from andythenorth's FISH NewGRF. It was created to adjust ship capacities in order to allow ships to seriously compete with other modes of transportation. Cargo capacities of most freighters are quadrupled and have their running costs and buy costs adjusted accordingly.

Changed ships (cargo capacity);
Whitgift Freight Barge
Saint Marie Barge Tug
Geneva Freight Barge
Pine Island Log Tug
Meteor Freighter
Little Cumbrea Freighter
Shark Island Livestock Ship
Marstein Freighter
Altamira Freighter
Eddystone Tanker
Dieze Container Barge
Cadiz Freighter
Constance Freight Barge
Nieuwpoort Freighter
Hopetown Tanker
Frisco Bay Freighter
Grindavik Reefer
Santorini Freighter
Maspalomos Freighter
Yokohama Tanker

Added ships;
Finisterre Freighter
Grizenesse Freighter
Harbour Point Trawler

Name of this Repo:  redFISH
Repository version: {{REPO_REVISION}}


----------------------
2 Usage and Parameters
----------------------

This set replaces the default ships with a new set. Unchanged from the original FISH, this NewGRF has three parameters. The first, if enabled, reduces the construction costs of canals, locks and aquaducts in order to provide more balanced between the different modes of transportation. The second allows a choice of ship's speed adjustments, ranging from slowing down ships, leaving them unchanged or increasing their speed. The last parameter allows restrictions on ship availability, where one can enabled all ships, only sea based ships or only river based ships.

----------------------
3 Building from source
----------------------

Usually there's not much which needs to be changed when you obtain the
source. Your friends will usually be
make
make install
Both will build the grf from source, the latter will also try to copy
the grf into your grf folder so that it is available for testing and
use straight away.

A brief overview over all Makefile targets is given here:

all:
This is the default target, if also no parameter is given to
make. It will simply build the grf file, if it needs building

depend:
Re-run the dependency check. Usually not manually needed.

docs:
Build the documentation files

bundle:
This target will create a directory called "<name>-nightly" and
	copy the grf file there and the documentation files, readme.txt,
	changelog.txt and license.txt

bundle_zip
	This will zip the bundle directory into one zip for distribution

bundle_tar
	This will tar the bundle directory into a tar archive for
	distribution or upload to bananas

bundle_src
	Creates a source bundle

install:
	This will create a tar archive (like bundle_tar) and copy it
	into the INSTALLDIR as specified in Makefile.local (or the
	default dir, if that isn't defined). Don't rely on a good
	detection of the default installation directory. It's
	especially bound to fail on windows machines.

distclean:
	This phony target cleans everything from a source bundle which
	wasn't shipped.

clean:
	This phony target will delete all files which this Makefile will
	create

mrproper:
	This phony target will delete also all directories created by
	different Makefile targets

remake:
	It's a shortcut for first cleaning the dir and then making the
	grf anew.

addcheck:
	Check whether there are some files required but not part of the
	repository.

check:
	Check the md5sum of the built newgrf against the supplied md5sum
	(Intended to be used when building from tar balls)


3.1 Speed issues
----------------

A note concerning the speed of the makefile:
It seems that the required tools using MinGW and / or msys are thoroughly
slow on windows. A few example run times for OpenGFX, same processor type
(both core 2 duo, 2.26GHz for the windows machine, 2.0 GHz for the OSX
machine). Note that the values given are the 'real' time. Even though
this varies more and is dependent on the processor load, that's what you
have to wait for; the 'user' times are quite low on the windows machine
(~16s), but that by no means reflects the build time. Times are from
OpenGFX r539 with makefile r199.

DEP_CHECK_TYPE         windows               bash native
                 native       in VM            (OSX)
none            1m23.360s      -             0m32.781s
mdep            1m54.484s   0m30.164s        0m33.807s
normal          2m37.857s      -             0m36.528s


3.2 Obtaining the source
------------------------

The source code can be obtained from the #openttdcoop DevZone at
    http://dev.openttdcoop.org/projects/redfish
or via mercurial checkout
    hg clone http://hg.openttdcoop.org/redfish



---------
4 Credits
---------

andythenorth et al.

--------------
5 License
--------------

GNU GPL v2
