ECS & FIRS & YETI original vehicle set (EFrefit.grf)

Enables standard TTD vehicles (trains, cars, airplanes, ships) to be refitted to any cargo up to date or NewGRF release.
Uses mostly default TTD graphics, those new are from 
1. (C) Michael Blunck's Cargoset 2003 with his most kind allowance
2. Edited vehicles from Cargoset 2003
3. OpenGFX++
4. Some other sets I don't remember from last release

Parametres
1st: Choo-choo trains - silly trains with choo choo sound


Please, report aby bug or malfunction to http://www.tt-forums.net/viewtopic.php?f=67&t=52116




Versions:

# 2014.11.26 (4)
Changed from NFO to NML.
Added supporst for all existing cargos (listed in NewGRF wiki)
99% of cargos has its own graphics
Universal vehicles are always enabled.


# 2012.08.04 (3)
Long time ago, where there were no changelogs


Coded by Jan �koch

Special thanks to all who contribute to NewGRF wiki http://wiki.ttdpatch.net/tiki-index.php?page=GRFActionsDetailed,
 and to Josef Drexler for hiw astonishing work with TTD


